VERSION = "1.0.0"
vVERSION = "v" + VERSION
URL_ARCHIVE = "https://github.com/Matteo-Valerio/pyBioPortal/raw/master/archive"