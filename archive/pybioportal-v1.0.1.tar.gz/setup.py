from setuptools import setup
import os
import sys
#from tools.conf_build import vVERSION

# if __name__ == "__main__":

#     # output folder for package distribution file tar.gz and whl
#     version_folder = f"dist/{vVERSION}/pypi"
    
#     # create output folder if not exists
#     if not os.path.exists(version_folder):
#         os.makedirs(version_folder)

#     # check if command is python setup.py
#     if len(sys.argv) == 1 and sys.argv[0] == "setup.py":
#         # adding option for building
#         sys.argv += ["sdist", "--dist-dir", version_folder]
#         sys.argv += ["bdist_wheel", "--dist-dir", version_folder]

setup()

# # Remove the build and pybioportal.egg-info directory after creating the packages
# if os.path.exists("build"):
#     if os.name == "nt":  # Check if running on Windows
#         os.system(f"rmdir /s /q build")
#     else:  # For Unix-like systems
#         os.system(f"rm -rf build")

# if os.path.exists("pybioportal.egg-info"):
#     if os.name == "nt":  # Check if running on Windows
#         os.system(f"rmdir /s /q pybioportal.egg-info")
#     else:  # For Unix-like systems
#         os.system(f"rm -rf pybioportal.egg-info")