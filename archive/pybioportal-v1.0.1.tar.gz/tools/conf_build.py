VERSION = "1.0.1"
vVERSION = "v" + VERSION
URL_ARCHIVE = "https://github.com/Matteo-Valerio/pyBioPortal/raw/master/archive"