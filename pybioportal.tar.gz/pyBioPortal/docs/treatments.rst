Treatments
==========

The module ``treatments`` provides functions related to *Treatments* section of 
`cBioPortal Web Public API <https://www.cbioportal.org/api/swagger-ui/index.html>`__.

.. automodule:: pyBioPortal.treatments
   :members:
   :undoc-members:
   :show-inheritance:

.. include:: treatments_nb.rst