Studies
=======

The module ``studies`` provides functions related to *Studies* section of 
`cBioPortal Web Public API <https://www.cbioportal.org/api/swagger-ui/index.html>`__.

.. automodule:: pyBioPortal.studies
   :members:
   :undoc-members:
   :show-inheritance:

.. include:: studies_nb.rst