Generic Assays
==============

The module ``generic_assays`` provides functions related to *Generic Assays* section of 
`cBioPortal Web Public API <https://www.cbioportal.org/api/swagger-ui/index.html>`__.

.. automodule:: pyBioPortal.generic_assays
   :members:
   :undoc-members:
   :show-inheritance:

.. include:: generic_assays_nb.rst