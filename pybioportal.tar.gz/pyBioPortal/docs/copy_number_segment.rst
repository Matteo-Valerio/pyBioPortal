Copy Number Segment
===================

The module ``copy_number_segment`` provides functions related to *Copy Number Segment* section of 
`cBioPortal Web Public API <https://www.cbioportal.org/api/swagger-ui/index.html>`__.

.. automodule:: pyBioPortal.copy_number_segment
   :members:
   :undoc-members:
   :show-inheritance:

.. include:: copy_number_segment_nb.rst