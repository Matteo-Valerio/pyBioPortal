Info
====

The module ``info`` provides functions related to *Info* section of 
`cBioPortal Web Public API <https://www.cbioportal.org/api/swagger-ui/index.html>`__.

.. automodule:: pyBioPortal.info
   :members:
   :undoc-members:
   :show-inheritance:

.. include:: info_nb.rst