Genes
=====

The module ``genes`` provides functions related to *Genes* section of 
`cBioPortal Web Public API <https://www.cbioportal.org/api/swagger-ui/index.html>`__.

.. automodule:: pyBioPortal.genes
   :members:
   :undoc-members:
   :show-inheritance:

.. include:: genes_nb.rst