Samples
=======

The module ``samples`` provides functions related to *Samples* section of 
`cBioPortal Web Public API <https://www.cbioportal.org/api/swagger-ui/index.html>`__.

.. automodule:: pyBioPortal.samples
   :members:
   :undoc-members:
   :show-inheritance:

.. include:: samples_nb.rst