Patients
========

The module ``patients`` provides functions related to *Patients* section of 
`cBioPortal Web Public API <https://www.cbioportal.org/api/swagger-ui/index.html>`__.

.. automodule:: pyBioPortal.patients
   :members:
   :undoc-members:
   :show-inheritance:

.. include:: patients_nb.rst